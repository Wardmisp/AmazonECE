<?php
$bdd = new PDO ('mysql:host=localhost;dbname=amazonece', 'root', '');

if (isset($_POST['forminscription']))
{
	$pseudoVins = htmlspecialchars($_POST['pseudoVins']);
	$mailVins = htmlspecialchars($_POST['mailVins']);
	$nomVins = htmlspecialchars($_POST['nomVins']);
	$imageprofil = basename($_FILES['imageprofil']);
	$imagefond =basename($_FILES['imagefond']);
	


	if(!empty($_POST['pseudoVins']) AND !empty($_POST['mailVins']) AND !empty($_POST['nomVins']) AND !empty($_POST['imageprofil']) AND !empty($_POST['imagefond']))
	{
		if (filter_var($mailVins, FILTER_VALIDATE_EMAIL))
		{
			$reqmail= $bdd-> prepare("SELECT * FROM vendeur WHERE mailV = ?");
			$reqmail-> execute(array($mailVins));
			$mailexist = $reqmail->rowCount();

			if($mailexist == 0)
			{
				$insertmbr = $bdd->prepare("INSERT INTO vendeur (pseudo,mailV,nomV,PpV,pcouvertureV) VALUES (?,?,?,?,?)");
				$insertmbr->execute(array($pseudoVins,$mailVins,$nomVins,$imageprofil,$imagefond));
				
				echo "ok!";
				$message = "Votre compte a bien été créer! <a href=\"connexion.php\">Me connecter</a>";		
			}
			else
			{
				$message = "Adresse déjà utilisé !";
			}
		}
		else
		{
			$message ="Votre adresse mail n'est pas valide !";
		}
	}
	else 
	{
		$message = "Tous les champs doivent être complétés !";
	}
}

?>
<?php
	if(isset($message))
	{
		echo '<font color="red">' .$message."</font>";
	}
?>