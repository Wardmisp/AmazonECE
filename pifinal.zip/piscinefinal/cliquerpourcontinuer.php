<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
<style>
@import url('https://fonts.googleapis.com/css?family=Lato:700');
</style>
<script>
function info(nom, description, prix, restant,video,photo){
  w=open("",'popup','width=400,height=400,toolbar=no,scrollbars=no,resizable=yes');	
  w.document.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"piscine.css\"/>");
  w.document.write("<img class = \"imgstuff \" src = \" "+photo+" \" height = \"30% \" width = \"30%\" />" );
  w.document.write("<title> Votre  :"+nom+"</title>");
  w.document.write("<body class =\"descristuff\"> Description :"+description+"<br>");
  w.document.write("Prix:"+prix+"<br>");
  w.document.write("Restant:" + restant +"<br>");
  if (video){
  w.document.write("<video width =\"160\" height =\"120\" controls><source src= "+video+" type = \"video/mp4\"></video>");
  }
  w.document.write("</body>");
  w.document.close();
}
</script>
<meta charset="UTF-8">
	<title> Amazon ECE</title>
<link rel="stylesheet" type="text/css" href="piscine.css"/>
</head>
<body>
<div id="header">
		<nav>
		<strong class="logo"><a href="Sinstest.php"> <img src = "logo1.png"/></a></strong>
		<ul>
			<li><a href = "panier.php"><img src ="imagedepanier.jpg" width="60" height="80"> </a></li>
			<li><a title="Des livres et nous" href = "livres.php">Livres</a></li>
			<li><a title="Poussons la chansonnette" href="musique.php">Musique</a></li>
			<li><a title="Habillement" href="vetements.php">Vêtements</a></li>
			<li><a title="Sports et Loisirs" href="sport.php">Sports et Loisirs</a></li>
			<li><a title="Connexion" href="compte.html">Se connecter</a></li>
			<li><a title="Vente Flash" href="ventelash.php">Ventes Flash</a></li>
		
		</ul>
	</nav>
	
	</div>
	
<?php
try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=amazonece;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}

		
$requete="UPDATE items SET IDAcheteur=-1 WHERE IDI='".$_GET['idi']."' AND IDVariation='".$_GET['idv']."'";
// On récupère le contenu

$bdd->exec($requete);
// On affiche chaque entrée une à une

?>

<p> votre produit a bien été ajouté au panier</p>
<a href="Sinstest.php"><input type="button"value="cliquer pour continuer">	
</table>
</form>
</body>

</html>