<!DOCTYPE html>
<head>
<style>
@import url('https://fonts.googleapis.com/css?family=Lato:700');
</style>
<script type="text/javascript" src="piscineJs.js"></script>

<meta charset="UTF-8">
	<title> Amazon ECE</title>
<link rel="stylesheet" type="text/css" href="piscine.css"/>
</head>
<body>
	<div id="header">
		<nav>
		<strong class="logo"><a href="Sinstest.php"> <img src = "logo.png"/></a></strong>
		<ul>
			<li><a title="Des livres et nous" href = "livres.php" >Livres</a></li>
			<li><a title="Poussons la chansonnette" href="musique.php">Musique</a></li>
			<li><a title="Habillement" href="vetements.php">Vêtements</a></li>
			<li><a title="Sports et Loisirs" href="sport.php">Sports et Loisirs</a></li>
			<li><a title="Connexion" href=<!-- A COMPLETER -->>Se connecter</a></li>
			<li><a title="Vente Flash" href="flash.php">Ventes Flash</a></li>
		</ul>
		</nav>
	</div>
	<ul><?php
try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=amazonECE;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}

// Si tout va bien, on peut continuer
$requete = 'SELECT * FROM items WHERE categorie = "Livres" ORDER BY IDI';
// On récupère le contenu
$reponse = $bdd->prepare($requete, array(PDO::ATTR_CURSOR => PDO::CURSOR_SCROLL));
$varia = $bdd->prepare($requete, array(PDO::ATTR_CURSOR => PDO::CURSOR_SCROLL));
$presentation = $bdd->prepare($requete, array(PDO::ATTR_CURSOR => PDO::CURSOR_SCROLL)); 
$reponse ->execute();
$varia -> execute();
$presentation -> execute();
$try = $varia->fetch(PDO::FETCH_NUM,PDO::FETCH_ORI_NEXT)[0];
$p = $presentation->fetch(PDO::FETCH_NUM,PDO::FETCH_ORI_NEXT);
$compteur = 0;
// On affiche chaque entrée une à une
while ($donnees = $reponse->fetch()){
	$var = 1;
	$array =[];
	$p=$presentation->fetch(PDO::FETCH_NUM,PDO::FETCH_ORI_NEXT);
	if  (($donnees['IDI'] < $try = $varia->fetch(PDO::FETCH_NUM,PDO::FETCH_ORI_NEXT)[0]) Or ($try == false)){
	?>
		<div class = "mainsection">
		<img title = "cliquez pour en savoir plus" src ="<?php echo $donnees['photoI']; ?>" onclick = "info('<?php echo $donnees['nomI'];?>','<?php echo $donnees['descriptionI'];?>','<?php echo $donnees['prixI'];?>','<?php echo $donnees['nombreI'];?>','<?php echo $donnees['videoI'];?>','<?php echo $donnees['photoI'];?>')"/>
		<span class= "nomItem"><h3><?php echo $donnees['nomI'];?></h3><br/></span></div>
	<?php } else{
		$compteur = $compteur +1;
				do {        
					$array[] = $p;
					$var = $var + 1 ;
					$p=$presentation->fetch(PDO::FETCH_NUM,PDO::FETCH_ORI_NEXT);
				}
				while ($donnees['IDI'] == $varia->fetch(PDO::FETCH_NUM,PDO::FETCH_ORI_NEXT)[0]);
	?>
			<div class = "mainsection">
			<a href = "variante.php?id=<?php echo $donnees['IDI'];?>" onclick="window.open(this.href); return false;"><img title = "cliquez pour en savoir plus" src ="<?php echo $donnees['photoI'];?>"/>
			<span class= "nomItem"><h3><?php echo $donnees['nomI'];?></h3><br/><h3 href = "variante.php?id=<?php echo $donnees['IDI'];?>" > Variantes disponible :<?php echo $var;?></h3></span></a></div>
				<?php for ($i = 1; $i < $var;$i++){
					$donnees = $reponse->fetch();
				}
	 }
}

$reponse->closeCursor(); // Termine le traitement de la requête

?>
		</ul>
</body>