<?php

$bdd = new PDO ('mysql:host=localhost ; dname=amazonece', 'root' , "");

if(!empty($)
$mailA= htlmspecialchars($_POST['mailA']);
