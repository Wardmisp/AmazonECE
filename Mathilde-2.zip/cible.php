<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
 		<title>Ceci est une page de test</title>
	</head>


	<body>
		<P>BONJOUR 
			<?php
			echo ($_POST['prenom']); 
			?> 
		</p>
		

	</body>
</html>