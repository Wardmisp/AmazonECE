<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="compte.css"/>
 	<title>Administrateur</title>
</head>


<body>
	<header>
		<div id="logo">
			<img src="LOGO_AZ_ECE.png" class="flottant" href="page d'acceuil"/>
		</div>
			<ul>
				<li><a title="Les Caégories" href="categories.html">Catégories</a></li>
				<li><a title="Ventes Flash" href="venteflash.html">Vente Flash</a></li>
				<li><a title="Vendre" href="vendre.html">Vendre</a></li>
				<li><a title="Connexion" href="Connexion.html">Se connecter</a></li>
				<li><a title="Panier" href="panier.html">Panier</a></li>
				<li><a title="Administrateur" href="administrateur.html">Administrateur</a></li>
			</ul>
	</header>

	<section>
	<?php
	session_start();

	$bdd = new PDO ('mysql:host=localhost;dbname=amazonece', 'root', '');

	if (isset($_POST['submitconnect'])) 
	{
		$mailAdconnect = htmlspecialchars($_POST['mailAdconnect']);
		$pseudoAdconnect = htmlspecialchars($_POST['pseudoAdconnect']);

		echo "ok bouton Connexion"."<br/>";

		if (!empty($mailAdconnect) AND !empty($pseudoAdconnect))
		{
			$requser = $bdd->prepare("SELECT * FROM vendeur WHERE mailV = ? AND pseudo = ?");
			$requser->execute(array($mailAdconnect,$pseudoAdconnect));

			echo "mail et pseudo sont complétés"."<br/>";
			echo "$pseudoAdconnect"."<br/>";
			echo "$mailAdconnect"."<br/>";

			$userexist = $requser->rowCount();

			if ($userexist == 1)
			{
				$userinfo = $requser->fetch();
				$_SESSION['IDAdmin'] = $userinfo['IDAdmin'];
				$_SESSION['nomV'] = $userinfo['nomV'];
				$_SESSION['mailV'] = $userinfo['mailV'];
				header("Location : profil.php?id=".$_SESSION['IDAdmin'] );
				echo "Vous êtes Connectez!";
			}
			else
			{
				$message = "Mauvais mail ou mot de passe !" ."<br/>";
			}
		}
		else
		{
			$message = " Tous les champs doivent être complétés !"."<br/>";
		}
	}

	?>
	<?php
		if(isset($message))
		{
			echo '<font color="red">' .$message."</font>";
		}
	?>
	</section>
	<footer>
 		<small>
 			<td align=”center”></td>
 			<p>Redigé par : Mathilde Giraudon. 
 			<br>
 			Contact: <a href="mailto:jean-pierre.segado.ece.fr">mathilde.giraudon@gmail.com</a></p>
 			<p>Copyright &copy;2019 Latest update: 
 				<time datetime="2019-04-29 18:00">Aujourd’hui</time></p>
 		</small>
	</footer>

</body>
</html>