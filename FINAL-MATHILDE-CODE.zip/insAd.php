<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="compte.css"/>
 	<title>Bienvenue</title>
</head>


<body>
	<header>
		<div id="logo">
			<img src="LOGO_AZ_ECE.png" class="flottant" href="page d'acceuil"/>
		</div>
			<ul>
				<li><a title="Des livres et nous" href=<!-- A COMPLETER -->>Livres</a></li>
				<li><a title="Poussons la chansonnette" href=<!-- A COMPLETER -->>Musique</a></li>
				<li><a title="Habillement" href=<!-- A COMPLETER -->>Vêtements</a></li>
				<li><a title="Sports et Loisirs" href=<!-- A COMPLETER -->>Sports et Loisirs</a></li>
				<li><a title="Connexion" href="Connexion.html">>Se connecter</a></li>
				<li><a title="Vente Flash" href=<!-- A COMPLETER -->>Ventes Flash</a></li>
			</ul>
	</header>
	
	<section>
	<?php

	$bdd = new PDO ('mysql:host=localhost;dbname=amazonece', 'root', '');

	if (isset($_POST['submitconnexion']))
	{
		$pseudoAdins = htmlspecialchars($_POST['pseudoAdins']);
		$mailAdins= htmlspecialchars($_POST['mailAdins']);
		$nomAdins = htmlspecialchars($_POST['nomAdins']);
		
		if(!empty($_POST['pseudoAdins']) AND !empty($_POST['mailAdins']) AND !empty($_POST['nomAdins']))
		{
			$pseudolength =strlen($pseudoAdins);
			if ($pseudolength <= 255 )
			{
				if (filter_var($mailAdins, FILTER_VALIDATE_EMAIL))
				{
					$reqmail= $bdd-> prepare("SELECT * FROM vendeur WHERE mailV = ?");
					$reqmail-> execute(array($mailAdins));
					$mailexist = $reqmail->rowCount();

					if($mailexist == 0)
					{
						$insertmbr = $bdd->prepare("INSERT INTO vendeur (pseudo, mailV, nomV) VALUES (?,?,?)");
						$insertmbr -> execute (array($pseudoAdins, $mailAdins, $nomAdins));
						$message = "Votre compte a bien été créer ! ";
					}
					else
					{
						$message = "Adresse déjà utilisé !";
					}
				}
				else
				{
					$message ="Votre adresse mail n'est pas valide !";
				}
			}
			else 
			{
				$message = "Votre pseudo ne doit pas dépasser 255 caractères! ";
			}
		}
		else 
		{
			$message = "Tous les champs doivent être complétés !";
		}
	}

	?>
	<?php
		if(isset($message))
		{
			echo '<font color="red">' .$message."</font>";
		}
	?>
	</section>
	<footer>
 		<small>
 			<td align=”center”></td>
 			<p>Redigé par : Mathilde Giraudon. 
 			<br>
 			Contact: <a href="mailto:jean-pierre.segado.ece.fr">mathilde.giraudon@gmail.com</a></p>
 			<p>Copyright &copy;2019 Latest update: 
 				<time datetime="2019-04-29 18:00">Aujourd’hui</time></p>
 		</small>
	</footer>
</body>
</html>
