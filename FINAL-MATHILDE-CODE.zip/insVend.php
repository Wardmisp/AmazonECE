<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="compte.css"/>
 	<title>Bienvenue</title>
</head>


<body>
	<header>
		<div id="logo">
			<img src="LOGO_AZ_ECE.png" class="flottant" href="page d'acceuil"/>
		</div>
			<ul>
				<li><a title="Des livres et nous" href=<!-- A COMPLETER -->>Livres</a></li>
				<li><a title="Poussons la chansonnette" href=<!-- A COMPLETER -->>Musique</a></li>
				<li><a title="Habillement" href=<!-- A COMPLETER -->>Vêtements</a></li>
				<li><a title="Sports et Loisirs" href=<!-- A COMPLETER -->>Sports et Loisirs</a></li>
				<li><a title="Connexion" href="Connexion.html">>Se connecter</a></li>
				<li><a title="Vente Flash" href=<!-- A COMPLETER -->>Ventes Flash</a></li>
			</ul>
	</header>
	
	<section>
		<?php
		$bdd = new PDO ('mysql:host=localhost;dbname=amazonece', 'root', '');

			$pseudoVins = htmlspecialchars($_POST['pseudoVins']);
			$mailVins = htmlspecialchars($_POST['mailVins']);
			$nomVins = htmlspecialchars($_POST['nomVins']);
			$imageprofil = htmlspecialchars($_POST['imageprofil']);
			$imagefond = htmlspecialchars($_POST['imagefond']);
				


			if(!empty($_POST['pseudoVins']) AND !empty($_POST['mailVins']) AND !empty($_POST['nomVins']) AND !empty($_POST['imageprofil']) AND !empty($_POST['imagefond']))
			{
				if (filter_var($mailVins, FILTER_VALIDATE_EMAIL))
				{
					$reqmail= $bdd-> prepare("SELECT * FROM vendeur WHERE mailV = ?");
					$reqmail-> execute(array($mailVins));
					$mailexist = $reqmail->rowCount();

					if($mailexist == 0)
					{
						$insertmbr = $bdd->prepare("INSERT INTO vendeur (pseudo,mailV,nomV,PpV,pcouvertureV) VALUES (?,?,?,?,?)");
						$insertmbr->execute(array($pseudoVins,$mailVins,$nomVins,$imageprofil,$imagefond));
						
						echo "ok!";
						$message = "Votre compte a bien été créer! <a href=\"connexion.php\">Me connecter</a>";		
					}
					else
					{
						$message = "Adresse déjà utilisé !";
					}
				}
				else
				{
					$message ="Votre adresse mail n'est pas valide !";
				}
			}
			else 
			{
				$message = "Tous les champs doivent être complétés !";
			}

			?>
			<?php
				if(isset($message))
				{
					echo '<font color="red">' .$message."</font>";
				}
			?>
	</section>
</body>
</html>
